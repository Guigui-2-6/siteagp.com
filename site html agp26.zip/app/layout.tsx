import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import type React from "react" // Import React

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AGP 26 - Plomberie, Chauffage, Climatisation",
  description:
    "Expert en plomberie, chauffage et climatisation dans la Drôme. Solutions sur mesure pour votre confort.",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>{children}</body>
    </html>
  )
}

