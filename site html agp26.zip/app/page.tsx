import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ContactForm } from "@/components/contact-form"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Wrench, Thermometer, Wind, Phone } from "lucide-react"
import type React from "react" // Import React

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-gray-900 overflow-hidden">
          <div className="max-w-7xl mx-auto">
            <div className="relative z-10 pb-8 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
              <div className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
                <div className="sm:text-center lg:text-left">
                  <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6xl">
                    <span className="block xl:inline">AGP 26</span>
                    <span className="block text-primary xl:inline">Votre expert en plomberie et chauffage</span>
                  </h1>
                  <p className="mt-3 text-base text-gray-300 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                    Plomberie, chauffage, climatisation et dépannage dans la Drôme. Des solutions sur mesure pour votre
                    confort.
                  </p>
                  <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                    <Button size="lg" asChild>
                      <a href="#contact">Contactez-nous</a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
            <Image
              className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full"
              src="https://cdn.iperceramica.it/asset/ambienti/complete/raku-bianco-latte-slimstone-avorio-bagno.jpg"
              alt="Salle de bain moderne"
              width={800}
              height={600}
              priority
            />
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-12 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Nos services</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                Des solutions complètes pour votre confort
              </p>
            </div>
            <div className="mt-10">
              <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
                <ServiceCard
                  icon={<Wrench className="h-8 w-8 text-primary" />}
                  title="Plomberie"
                  description="Installation et réparation de systèmes de plomberie"
                />
                <ServiceCard
                  icon={<Thermometer className="h-8 w-8 text-primary" />}
                  title="Chauffage"
                  description="Installation et entretien de systèmes de chauffage"
                />
                <ServiceCard
                  icon={<Wind className="h-8 w-8 text-primary" />}
                  title="Climatisation"
                  description="Installation et maintenance de systèmes de climatisation"
                />
                <ServiceCard
                  icon={<Phone className="h-8 w-8 text-primary" />}
                  title="Dépannage"
                  description="Service de dépannage rapide et efficace"
                />
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-primary font-semibold tracking-wide uppercase">À propos de nous</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                AGP 26 : Votre partenaire de confiance
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                Depuis notre création, nous nous efforçons de fournir des services de qualité à nos clients dans la
                Drôme. Notre mission est de garantir votre confort et votre tranquillité d'esprit grâce à notre
                expertise en plomberie, chauffage et climatisation.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-12 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center mb-12">
              <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Contactez-nous</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                Besoin d'un devis ou d'une intervention ?
              </p>
            </div>
            <div className="max-w-2xl mx-auto">
              <ContactForm />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

function ServiceCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center">
          {icon}
          <h3 className="ml-3 text-lg font-medium text-gray-900">{title}</h3>
        </div>
        <p className="mt-2 text-base text-gray-500">{description}</p>
      </CardContent>
    </Card>
  )
}

