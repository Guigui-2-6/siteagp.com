import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { MobileNav } from "./mobile-nav"

export function Header() {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Image src="/logo-06-sans-arriere-plan.svg" alt="Logo AGP 26" width={120} height={48} priority />
        </div>
        <MobileNav />
        <nav className="hidden md:block">
          <ul className="flex space-x-4 items-center">
            <li>
              <Link href="#services" className="text-gray-600 hover:text-gray-900">
                Services
              </Link>
            </li>
            <li>
              <Link href="#about" className="text-gray-600 hover:text-gray-900">
                À propos
              </Link>
            </li>
            <li>
              <Link href="#contact" className="text-gray-600 hover:text-gray-900">
                Contact
              </Link>
            </li>
            <li>
              <Button>Devis gratuit</Button>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  )
}

