"use client"

import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"
import Link from "next/link"

export function MobileNav() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left">
        <nav className="flex flex-col space-y-4">
          <Link href="#services" className="text-lg font-medium">
            Services
          </Link>
          <Link href="#about" className="text-lg font-medium">
            À propos
          </Link>
          <Link href="#contact" className="text-lg font-medium">
            Contact
          </Link>
          <Button className="w-full">Devis gratuit</Button>
        </nav>
      </SheetContent>
    </Sheet>
  )
}

